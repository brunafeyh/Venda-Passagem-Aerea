#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "cliente.h"
#include "cliente_file.h"
#include "venda.h"
#include "venda_file.h"
#define MAXS 250

//Pré-condições: função deve imprimir na tela as opções do menu, no seguinte formato "opção - descrição da opção"
//Pós-condições: nenhuma
//Resultado: opções do menu impressas no terminal para que o usuário possa visualizar
void header_menu(){
    printf("------------- MENU -------------\n");
    printf("Insira a opção desejada:        |\n");
    printf("1 - Inserir cliente             |\n");
    printf("2 - Consultar cliente           |\n");
    printf("3 - Registrar venda de passagem |\n");
    printf("4 - Cancelar                    |\n");
    printf("--------------------------------\n");
}

//Pré-condições: função deve avaliar se a opção digitada pelo usuário é válida, caso não seja, solicita a inseção da opção novamente
//Pós-condições: nenhuma
//Resultado: retorna uma das opções corretas e validada
int validar_opcao(){
    int opcao;
    header_menu();
    scanf("%d", &opcao);
    while(opcao != 1 && opcao != 2 && opcao != 3 && opcao != 4){
        printf("Opção inválida, selecione novamente\n\n");
        header_menu();
        scanf("%d", &opcao);
    }
    return opcao;
}

//Pré-condições: função faz o controle de distribuição das funções de registro de cliente, busca de cliente e registro de venda
//Pós-condições: nenhuma
//Resultado: deve atender a opção desejada pelo usuário e realizar as funções de acordo com o que é solicitado pelo usuário
void menu(){
    int opcao;
    CLIENTE passageiro;
    VENDA passagem;
   
    while((opcao = validar_opcao()) != 4){
   
        if(opcao == 1){
            system("clear");
            printf("\nOpção selecionada: inserir cliente");
            inserir_cliente(&passageiro);
            inserir_cliente_file(passageiro);
            printf("Cliente inserido com sucesso!\n\n");
        }
       
        if(opcao == 2){
            system("clear");
            printf("\nOpção selecionada: consultar cliente\n");
            buscar_cliente(&passageiro);
        }
       
        if(opcao == 3){
            system("clear");
            printf("\nOpção selecionada: registrar venda de passagem\n");
            registrar_venda(&passagem);
            registrar_venda_file(passagem);
            printf("Venda registrada  com sucesso! \n\n");
        }
       
    }
   
    if(opcao == 4){
        system("clear");
        printf("Encerrando programa\n");
    }
}