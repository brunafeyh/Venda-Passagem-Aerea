#include <stdio.h>
#include <errno.h>
#include <string.h>
#include "cliente_file.h"
#include "file.h"

//Pré-condições: função deve inserir o registro de um cliente em um arquivo cliente.txt
//Pós-condições: O arquivo cliente.txt deve manter as informações que já estavam armazenadas
//Resultado: os dados do cliente devem estar registrados em uma única linha e separados por ";" (ponto e vírgula)
int inserir_cliente_file(CLIENTE passageiro){
    FILE * file;
    
    file = fopen("cliente.txt", "a+");
    verificar_file(file);
    
    fprintf(file, "%s;%s;%d\n", passageiro.nome, passageiro.rg, passageiro.code_fidelidade);
    
    fclose(file);
    return 0;
}

//Pré-condições: função deve buscar o registro de um cliente no arquivo cliente.txt, a busca é realizada por rg 
//Pós-condições: O arquivo cliente.txt deve manter as informações que já estavam armazenadas
//Resultado: retorna true se o rg de busca é compatível com algum cliente que está registrado no arquivo, caso contrário retorna false.
//           Também retorna o cliente encontrado em uma struct CLIENTE ponteiro
bool buscar_cliente_file(CLIENTE * passageiro, char rg_passageiro[]){
    FILE * file;
    
    file = fopen("cliente.txt", "r");
    verificar_file(file);
    
    while(fscanf(file, "%[^;]%*c", passageiro->nome) != EOF){
        fscanf(file, "%[^;]%*c", passageiro->rg);
        fscanf(file, "%d%*c", &passageiro->code_fidelidade);
        
        if(strcmp(passageiro->rg, rg_passageiro) == 0)
            return true;
    }
    
    fclose(file);
    return false;
}

//Pré-condições: função deve analisar se um dado rg já está cadastrado no arquivo cliente.txt
//Pós-condições: O arquivo cliente.txt deve manter as informações que já estavam armazenadas
//Resultado: retorna true se o rg de busca é compatível com algum cliente que está registrado no arquivo, caso contrário retorna false.
bool verificar_rg_existente(char rg_passageiro[]){
    FILE * file;
    char nome[250], rg[250];
    int codigo_fidelidade;
    
    file = fopen("cliente.txt", "r");
    verificar_file(file);
    
    while(fscanf(file, "%[^;]%*c", nome) != EOF){
        fscanf(file, "%[^;]%*c", rg);
        fscanf(file, "%d%*c", &codigo_fidelidade);
        
        if(strcmp(rg, rg_passageiro) == 0)
            return true;
    }
    
    fclose(file);
    return false;
}