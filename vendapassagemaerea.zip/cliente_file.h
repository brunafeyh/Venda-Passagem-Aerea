#ifndef CLIENTE_FILE_H
#define CLIENTE_FILE_H
#include <stdbool.h>
#include "cliente.h"

int inserir_cliente_file(CLIENTE passageiro);
bool buscar_cliente_file(CLIENTE * passageiro, char rg_passageiro[]);
bool verificar_rg_existente(char rg_passageiro[]);

#endif /* CLIENTE_FILE_H */