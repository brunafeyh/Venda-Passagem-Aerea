/*
    Desenvolvido por: André Luis Correa Cano.
                      Anny Karoline Dellani.
                      Bruna Carolina da Silva Feyh.
    
    20 de setembro de 2023.
                      
    Esta é uma versão atualizada do código, contendo as correções analisadas pelo professor em sala.
*/
#include <stdio.h>
#include "menu.h"

int main()
{
    menu();
    return 0;
}
