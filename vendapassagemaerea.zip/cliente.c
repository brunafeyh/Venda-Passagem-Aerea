#include <stdio.h>
#include "cliente.h"
#include "cliente_file.h"

//Pré-condições: função deve armazenar os dados (inseridos pelo usuário) do cliente em uma struct CLIENTE
//Pós-condições: nenhuma
//Resltado: a struct CLIENTE deve ser ponteiro contendo todos os dados do cliente
void inserir_cliente(CLIENTE * passageiro){
    printf("\nDigite o nome: ");
    scanf("%*c%[^\n]%*c", passageiro->nome);
    
    printf("Digite o RG: ");
    scanf("%[^\n]%*c", passageiro->rg);
    
    while(verificar_rg_existente(passageiro->rg)){
        printf("Cliente já registrado com esse RG, insira outro: ");
        scanf("%[^\n]%*c", passageiro->rg);
    }
    
    printf("Digite o código de fidelidade: ");
    scanf("%d", &passageiro->code_fidelidade);
}

//Pré-condições: função deve buscar o registro de um cliente, a função solicita um rg do usuário
//               e utiliza a função "bool buscar_cliente_file(CLIENTE * passageiro, char rg_passageiro[]);",
//               que está presente no conjunto de funções de cliente_file.c
//Pós-condições: nenhuma
//Resultado: se "buscar_cliente_file()" retornar true, então imprime os dados do cliente na tela.
bool buscar_cliente(CLIENTE * passageiro){
    char rg_referencia[MAXS];
    printf("Digite o RG de referência para a busca: ");
    scanf("%s%*c", rg_referencia);
    
    if(buscar_cliente_file(passageiro, rg_referencia)){
        printf("\n-----Cliente localizado!-----\n");
        imprimir_cliente(*passageiro);
        return true;
    }
    
    printf("Não foi possível localizar o cliente!\n\n");
    return false;
}

//Pré-condições: função deve imprimir na tela os dados de um cliente
//Pós-condições: nenhuma
//Resultado: dados de um cliente impressos no terminal de forma organizada, contendo um dado por linha
void imprimir_cliente(CLIENTE passageiro){
    printf("Nome: %s\n", passageiro.nome);
    printf("RG: %s\n", passageiro.rg);
    printf("Código de fidelidade: %d\n", passageiro.code_fidelidade);
    printf("----------------------------\n\n");
}

//Pré-condições: função deve contar o número de dígitos de um número inteiro
//Pós-condições: nenhuma
//Resultado: retorna a quantidade de dígitos de um dado número inteiro
int contar_digitos(int codigo){
    int contador = 0;
    
    while(codigo != 0){
        contador++;
        codigo /= 10;
    }
    
    return contador;
}

//Pré-condições: função deve analisar se um cliente possui programa de fidelidade GOLD, isto é, se último dígito do Código
//               de fidelidade for 1
//Pós-condições: nenhuma
//Resultado: retorna true se é cliente GOLD, caso contrário, false
bool is_gold(CLIENTE passageiro){
    int tamanhoCode = contar_digitos(passageiro.code_fidelidade);
    int ultimo_digito = passageiro.code_fidelidade%10;
    
    if(tamanhoCode == 4 && ultimo_digito == 1)
        return true;
        
    return false;
}

//Pré-condições: função deve analisar se um cliente possui programa de fidelidade SILVER, isto é, se último dígito do Código
//               de fidelidade for 2
//Pós-condições: nenhuma
//Resultado: retorna true se é cliente SILVER, caso contrário, false
bool is_silver(CLIENTE passageiro){
    int tamanhoCode = contar_digitos(passageiro.code_fidelidade);
    int ultimo_digito = passageiro.code_fidelidade%10;
    
    if(tamanhoCode == 4 && ultimo_digito == 2)
        return true;
        
    return false;
}

//Pré-condições: função deve analisar se um cliente é empregado CIA, o usuário insere a resposta 'S' para sim e 'N' para não
//Pós-condições: nenhuma
//Resultado: retorna true se é empregado CIA, caso contrário, false
bool is_empregado_cia(CLIENTE passageiro){
    char resposta;
    printf("O cliente é funcionário CIA? Responder S (sim) ou N (nao): ");
    scanf("%c", &resposta);
    
    if(resposta == 'S')
        return true;
    return false;
}