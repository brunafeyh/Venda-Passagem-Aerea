#ifndef MENU_H
#define MENU_H

void header_menu();

int validar_opcao();

void menu();

#endif /* MENU_H */