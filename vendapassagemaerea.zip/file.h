#ifndef FILE_H
#define FILE_H

void verificar_file(FILE * arquivo);

#endif /* FILE_H */