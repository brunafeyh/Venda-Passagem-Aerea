#include <stdio.h>
#include <stdlib.h>

//Pré-condições: função deve verificar se um arquivo é válido
//Pós-condições: nenhuma
//Resultado: caso o arquivo seja inválidoo programa deve ser encerrado
void verificar_file(FILE * arquivo){
    if(arquivo == NULL){
        printf("Encontramos um erro: Arquivo inválido!\nEncerrando programa\n");
        exit(0);
    }
}
