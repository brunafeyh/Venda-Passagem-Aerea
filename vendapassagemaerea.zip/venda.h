#ifndef VENDA_H
#define VENDA_H
#define MAXS 250
#include "cliente.h"

typedef struct{
    char sigla_origem[MAXS];
    char sigla_destino[MAXS];
    CLIENTE passageiro; 
    double valor_passagem;
    double valor_passagem_final;
} VENDA;

double calcular_desconto(CLIENTE passageiro, double valor_passagem);
void registrar_venda(VENDA * passagem);

#endif /* VENDA_H */
