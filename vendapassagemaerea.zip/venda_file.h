#ifndef VENDA_FILE_H
#define VENDA_FILE_H
#include "venda.h"

int registrar_venda_file(VENDA passagem);

#endif /* VENDA_FILE_H */