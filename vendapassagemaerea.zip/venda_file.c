#include <stdio.h>
#include <errno.h>
#include "venda_file.h"
#include "file.h"

//Pré-condições: função deve inserir o registro de uma venda em um arquivo venda.txt
//Pós-condições: O arquivo venda.txt deve manter as informações que já estavam armazenadas
//Resultado: os dados da venda devem estar registrados em uma única linha e separados por ";" (ponto e vírgula)
int registrar_venda_file(VENDA passagem){
    FILE * file;
    
    file = fopen("venda.txt", "a+");
    verificar_file(file);
    
    fprintf(file, "%s;%s;%s;%s;%d;%.2lf;%.2lf\n", passagem.sigla_origem, passagem.sigla_destino, 
                                              passagem.passageiro.nome, passagem.passageiro.rg,
                                              passagem.passageiro.code_fidelidade, passagem.valor_passagem,
                                              passagem.valor_passagem_final);
    
    fclose(file);
    return 0;
}