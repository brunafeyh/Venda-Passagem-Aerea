#ifndef CLIENTE_H
#define CLIENTE_H
#define MAXS 250
#include <stdbool.h>

typedef struct{
    char nome[MAXS];
    char rg[MAXS];
    int code_fidelidade;
} CLIENTE;

void inserir_cliente(CLIENTE * passageiro);
bool buscar_cliente(CLIENTE * passageiro);
void imprimir_cliente(CLIENTE passageiro);
int contar_digitos(int codigo);
bool is_gold(CLIENTE passageiro);
bool is_silver(CLIENTE passageiro);
bool is_empregado_cia(CLIENTE passageiro);

#endif /* CLIENTES_H */



