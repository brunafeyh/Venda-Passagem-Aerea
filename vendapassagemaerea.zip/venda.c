#include <stdio.h>
#include "venda.h"
#include "cliente.h"

//Pré-condições: função deve calcular o valor final da passagem (com descontos), considerando o programa fidelidade de cada cliente
//Pós-condições: nenhuma
//Resultado: retorna o valor final da passagem após aplicados os possíveis descontos
double calcular_desconto(CLIENTE passageiro, double valor_passagem){
    double valor_final = valor_passagem;
    
    if(is_gold(passageiro))
        valor_final -= (valor_passagem * 0.2);

    if(is_silver(passageiro))
        valor_final -= (valor_passagem * 0.15);
    
    if(is_empregado_cia(passageiro))
        valor_final -= (valor_passagem * 0.05);
        
    return valor_final;
}

//Pré-condições: função deve armazenar os dados (inseridos pelo usuário) da passagem em uma struct VENDA
//Pós-condições: nenhuma
//Resltado: a struct VENDA deve ser ponteiro contendo todos os dados da venda
void registrar_venda(VENDA * passagem){
    printf("Digite a sigla do aeroporto de origem: ");
    scanf("%s%*c", passagem->sigla_origem);
    
    printf("Digite a sigla do aeroporto de destino: ");
    scanf("%s%*c", passagem->sigla_destino);
    
    while(!buscar_cliente(&passagem->passageiro)){
        ;
    }
    
    printf("Digite o valor total da passagem: ");
    scanf("%lf%*c", &passagem->valor_passagem);
    
    passagem->valor_passagem_final = calcular_desconto(passagem->passageiro, passagem->valor_passagem);
}





